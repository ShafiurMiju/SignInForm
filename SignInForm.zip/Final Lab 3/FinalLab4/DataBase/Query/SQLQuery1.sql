﻿CREATE TABLE users(
Email Varchar(30) NOT NULL,
Password Varchar(30) NOT NULL

PRIMARY KEY (Email),
);

INSERT INTO users (Email, Password) VALUES('abc@gmail.com', 'pass123');
INSERT INTO users (Email, Password) VALUES('xyz@gmail.com', 'pass789');

SELECT * FROM users;