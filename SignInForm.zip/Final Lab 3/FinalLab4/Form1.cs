﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalLab4
{
    public partial class Form1 : Form
    {
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
            (int Left, int Top, int Right, int Bottom, int Width, int Height);

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();

        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hwnd, int wmsg, int wparam, int lparam);

        string pattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|" + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)" + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";

        public Form1()
        {
            InitializeComponent();
            customizeDesign();
            this.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, this.Width, this.Height, 20, 20));
            loginBtn.Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, loginBtn.Width, loginBtn.Height, 7, 7));
        }

        private void customizeDesign()
        {
            panel19.Visible = false;
            panel1.Height = 390;
            panel22.Height = 8;
            panel23.Height = 10;
        }

        private void hideDesign(Panel p)
        {
            if (p.Visible == false)
                p.Visible = true;
        }

        private void showDesign(Panel p)
        {
            if (p.Visible == false)
            {
                p.Visible = true;
            }
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {

        }

        private void customTextBox1__TextChanged_1(object sender, EventArgs e)
        {
            if (label9.Visible == true)
            {
                label9.Visible = false;
                panel22.Height = 10;
                if (panel19.Visible == true)
                {
                    if (label12.Visible == true)
                        panel1.Height = 534;
                    else
                        panel1.Height = 520;
                }
                else if (label12.Visible == true)
                    panel1.Height = 406;
                else
                    panel1.Height = 390;
            }
        }

        private void customTextBox1_Enter(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "ENTER EMAIL ADDRESS")
            {
                customTextBox1.Texts = "";
                customTextBox1.ForeColor = Color.Black;
            }
        }

        private void customTextBox1_Leave(object sender, EventArgs e)
        {
            if (customTextBox1.Texts == "")
            {
                customTextBox1.Texts = "ENTER EMAIL ADDRESS";
                customTextBox1.ForeColor = Color.DimGray;
            }

            else
            {
                if (Regex.IsMatch(customTextBox1.Texts, pattern) == false)
                {
                    customTextBox1.Focus();
                    panel22.Height = 26;
                    label9.Visible = true;
                    label9.Text = "Enter a valid email address";

                    if (panel19.Visible == true)
                        panel1.Height = 466;
                    else
                        panel1.Height = 422;
                }
            }
        }

        private void customTextBox2__TextChanged(object sender, EventArgs e)
        {
            if (label12.Visible == true)
            {
                label12.Visible = false;
                panel23.Height = 10;
                if (panel19.Visible == true)
                {
                    if (label9.Visible == true)
                        panel1.Height = 534;
                    else
                        panel1.Height = 520;
                }
                else if (label9.Visible == true)
                    panel1.Height = 406;
                else
                    panel1.Height = 390;
            }
        }

        private void customTextBox2_Enter(object sender, EventArgs e)
        {
            if (customTextBox2.Texts == "ENTER PASSWORD")
            {
                customTextBox2.Texts = "";
                customTextBox2.ForeColor = Color.Black;
                customTextBox2.PasswordChar = true;
            }
        }

        private void customTextBox2_Leave(object sender, EventArgs e)
        {
            if (customTextBox2.Texts == "")
            {
                customTextBox2.Texts = "ENTER PASSWORD";
                customTextBox2.ForeColor = Color.DimGray;
                customTextBox2.PasswordChar = false;
            }
        }

        private void loginBtn_Click_1(object sender, EventArgs e)
        {
            SqlConnection sqlCon = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Acer\source\repos\FinalLab4\FinalLab4\DataBase\login.mdf;Integrated Security=True;Connect Timeout=30");

            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();

                String queryUsers = "SELECT COUNT(*) FROM Users WHERE Email=@Email AND Password=@Password";

                SqlCommand sqlCmdUsers = new SqlCommand(queryUsers, sqlCon);
                sqlCmdUsers.CommandType = CommandType.Text;
                sqlCmdUsers.Parameters.AddWithValue("@Email", customTextBox1.Texts);
                sqlCmdUsers.Parameters.AddWithValue("@Password", customTextBox2.Texts);
                int Users = Convert.ToInt32(sqlCmdUsers.ExecuteScalar());

                try
                {
                    if (Users == 1)
                    {
                        this.Hide();
                        Form2 f2 = new Form2();
                        f2.ShowDialog();

                    }

                    else if (customTextBox1.Texts == "ENTER EMAIL ADDRESS" || customTextBox2.Texts == "ENTER PASSWORD")
                    {
                        if (customTextBox1.Texts == "ENTER EMAIL ADDRESS" && customTextBox2.Texts == "ENTER PASSWORD")
                        {
                            panel22.Height = 26;
                            label9.Visible = true;
                            label9.Text = "The User Name field is required.";
                            panel23.Height = 26;
                            label12.Visible = true;

                            if (panel19.Visible == true)
                                panel1.Height = 466;
                            else
                                panel1.Height = 422;
                        }
                        else if (customTextBox1.Texts == "ENTER EMAIL ADDRESS")
                        {
                            panel22.Height = 26;
                            label9.Visible = true;
                            label9.Text = "The User Name field is required.";

                            if (panel19.Visible == true)
                                panel1.Height = 450;
                            else
                                panel1.Height = 406;
                        }
                        else if (customTextBox2.Texts == "ENTER PASSWORD")
                        {
                            panel23.Height = 26;
                            label12.Visible = true;

                            if (panel19.Visible == true)
                                panel1.Height = 450;
                            else
                                panel1.Height = 406;
                        }

                    }

                    else
                    {
                        panel1.Height = 450;
                        customTextBox2.Texts = "ENTER PASSWORD";
                        customTextBox2.PasswordChar = false;
                        customTextBox2.ForeColor = Color.DimGray;
                        showDesign(panel19);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            catch (Exception ex)
            {
                if (customTextBox1.Texts == "ENTER EMAIL ADDRESS" || customTextBox2.Texts == "ENTER PASSWORD")
                {
                    if (customTextBox1.Texts == "ENTER EMAIL ADDRESS" && customTextBox2.Texts == "ENTER PASSWORD")
                    {
                        panel22.Height = 26;
                        label9.Visible = true;
                        label9.Text = "The User Name field is required.";
                        panel23.Height = 26;
                        label12.Visible = true;

                        if (panel19.Visible == true)
                            panel1.Height = 450;
                        else
                            panel1.Height = 422;
                    }
                    else if (customTextBox1.Texts == "ENTER EMAIL ADDRESS")
                    {
                        panel22.Height = 26;
                        label9.Visible = true;
                        label9.Text = "The User Name field is required.";

                        if (panel19.Visible == true)
                            panel1.Height = 450;
                        else
                            panel1.Height = 406;
                    }
                    else if (customTextBox2.Texts == "ENTER PASSWORD")
                    {
                        panel23.Height = 26;
                        label12.Visible = true;

                        if (panel19.Visible == true)
                            panel1.Height = 450;
                        else
                            panel1.Height = 406;
                    }

                }

                else
                {
                    panel1.Height = 520;
                    customTextBox2.Texts = "ENTER PASSWORD";
                    customTextBox2.PasswordChar = false;
                    customTextBox2.ForeColor = Color.DimGray;
                    showDesign(panel19);
                }
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void label2_MouseHover(object sender, EventArgs e)
        {
            label2.ForeColor = Color.Blue;
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            label2.ForeColor = Color.Black;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, 0xA1, 0x2, 0);
            }
        }
    }
}
